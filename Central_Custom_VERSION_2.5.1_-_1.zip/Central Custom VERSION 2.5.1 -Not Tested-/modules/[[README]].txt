Put autoexecute files in autoexecute floder of your exploit
Put the others floder in the vape folder
Put the CustomModules folder in your vape folder
--Credits of Custom to CycloneHacks