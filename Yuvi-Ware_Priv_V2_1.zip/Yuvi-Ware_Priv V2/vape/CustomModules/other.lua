shared.CustomSaveVape = 6872274481
if pcall(function() readfile("vapeprivate/CustomModules/6872274481.lua") end) then
	loadstring(readfile("vapeprivate/CustomModules/6872274481.lua"))()
end