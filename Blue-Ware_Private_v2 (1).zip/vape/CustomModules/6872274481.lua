GuiLibrary["ObjectsThatCanBeSaved"]["RenderWindow"]["Api"]
local esp = Render.CreateOptionsButton({
    Name = "Night",
    HoverText = "Your Bedtime Little Boy",
    Function = function(v)
        if v then
            game.Lighting.TimeOfDay = "00:00:00"
        else
            game.Lighting.TimeOfDay = "13:00:00"
        end
    end
})
