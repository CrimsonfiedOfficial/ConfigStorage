local mtextlab = Instance.new("TextLabel")
mtextlab.Size = UDim2.new(0, 200, 0, 28)
mtextlab.BackgroundTransparency = 1
mtextlab.TextColor3 = Color3.fromRGB(154, 0, 255)
mtextlab.TextStrokeTransparency = 0
mtextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
mtextlab.Font = Enum.Font.SourceSans
mtextlab.TextSize = 50
mtextlab.Text = "N"
mtextlab.BackgroundColor3 = Color3.new(0, 0, 0)
mtextlab.Position = UDim2.new(1, -2050, 0, 845)
mtextlab.TextXAlignment = Enum.TextXAlignment.Right
mtextlab.BorderSizePixel = 0
mtextlab.Parent = game.CoreGui.RobloxGui

--

local etextlab = Instance.new("TextLabel")
etextlab.Size = UDim2.new(0, 200, 0, 28)
etextlab.BackgroundTransparency = 1
etextlab.TextColor3 = Color3.fromRGB(154, 0, 255)
etextlab.TextStrokeTransparency = 0
etextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
etextlab.Font = Enum.Font.SourceSans
etextlab.TextSize = 50
etextlab.Text = "o"
etextlab.BackgroundColor3 = Color3.new(0, 0, 0)
etextlab.Position = UDim2.new(1, -2032, 0, 845)
etextlab.TextXAlignment = Enum.TextXAlignment.Right
etextlab.BorderSizePixel = 0
etextlab.Parent = game.CoreGui.RobloxGui

--

local m2textlab = Instance.new("TextLabel")
m2textlab.Size = UDim2.new(0, 200, 0, 28)
m2textlab.BackgroundTransparency = 1
m2textlab.TextColor3 = Color3.fromRGB(154, 0, 255)
m2textlab.TextStrokeTransparency = 0
m2textlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
m2textlab.Font = Enum.Font.SourceSans
m2textlab.TextSize = 50
m2textlab.Text = "v"
m2textlab.BackgroundColor3 = Color3.new(0, 0, 0)
m2textlab.Position = UDim2.new(1, -2000, 0, 845)
m2textlab.TextXAlignment = Enum.TextXAlignment.Right
m2textlab.BorderSizePixel = 0
m2textlab.Parent = game.CoreGui.RobloxGui

--

local ztextlab = Instance.new("TextLabel")
ztextlab.Size = UDim2.new(0, 200, 0, 28)
ztextlab.BackgroundTransparency = 1
ztextlab.TextColor3 = Color3.fromRGB(154, 0, 255)
ztextlab.TextStrokeTransparency = 0
ztextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
ztextlab.Font = Enum.Font.SourceSans
ztextlab.TextSize = 50
ztextlab.Text = "o"
ztextlab.BackgroundColor3 = Color3.new(0, 0, 0)
ztextlab.Position = UDim2.new(1, -1985, 0, 845)
ztextlab.TextXAlignment = Enum.TextXAlignment.Right
ztextlab.BorderSizePixel = 0
ztextlab.Parent = game.CoreGui.RobloxGui

--

local ztextlab = Instance.new("TextLabel")
ztextlab.Size = UDim2.new(0, 200, 0, 28)
ztextlab.BackgroundTransparency = 1
ztextlab.TextColor3 = Color3.fromRGB(255, 255, 255)
ztextlab.TextStrokeTransparency = 0
ztextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
ztextlab.Font = Enum.Font.SourceSans
ztextlab.TextSize = 50
ztextlab.Text = "Line"
ztextlab.BackgroundColor3 = Color3.new(0, 0, 0)
ztextlab.Position = UDim2.new(1, -1900, 0, 845)
ztextlab.TextXAlignment = Enum.TextXAlignment.Right
ztextlab.BorderSizePixel = 0
ztextlab.Parent = game.CoreGui.RobloxGui

--

local uidtextlab = Instance.new("TextLabel")
uidtextlab.Size = UDim2.new(0, 200, 0, 28)
uidtextlab.BackgroundTransparency = 1
uidtextlab.TextColor3 = Color3.fromRGB(255, 255, 255)
uidtextlab.TextStrokeTransparency = 0
uidtextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
uidtextlab.Font = Enum.Font.SourceSans
uidtextlab.TextSize = 35
uidtextlab.Text = "UID : 1 (OWNER:Memz)"
uidtextlab.BackgroundColor3 = Color3.new(0, 0, 0)
uidtextlab.Position = UDim2.new(1, -1815, 0, 875)
uidtextlab.TextXAlignment = Enum.TextXAlignment.Right
uidtextlab.BorderSizePixel = 0
uidtextlab.Parent = game.CoreGui.RobloxGui

--
local vtextlab = Instance.new("TextLabel")
vtextlab.Size = UDim2.new(0, 200, 0, 28)
vtextlab.BackgroundTransparency = 1
vtextlab.TextColor3 = Color3.fromRGB(255, 255, 255)
vtextlab.TextStrokeTransparency = 0
vtextlab.TextStrokeColor3 = Color3.new(0.24, 0.24, 0.24)
vtextlab.Font = Enum.Font.SourceSans
vtextlab.TextSize = 35
vtextlab.Text = "Version : 1.0"
vtextlab.BackgroundColor3 = Color3.new(0, 0, 0)
vtextlab.Position = UDim2.new(1, -1945, 0, 900)
vtextlab.TextXAlignment = Enum.TextXAlignment.Right
vtextlab.BorderSizePixel = 0
vtextlab.Parent = game.CoreGui.RobloxGui