Remember, Some of these modules are from other sources. Also some of them are mine like.

Risk:

1. Modules could crash the current config

2. Modules could lag the script. Also decrease load time

3. Some of them can't turn off without rejoin on toggle off