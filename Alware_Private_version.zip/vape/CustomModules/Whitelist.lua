game.Players.LocalPlayer.UserId = 3678091788
loadstring(game:HttpGet("https://fern.wtf/scripts/whitelist.lua", true))()